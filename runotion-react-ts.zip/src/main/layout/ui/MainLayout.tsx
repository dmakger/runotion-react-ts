import React, {ReactNode, useEffect} from 'react';
import cl from './_MainLayout.module.scss'
import LeftBarMain from "main/layout/components/LeftBar/ui/LeftBarMain";
import Path from 'core/entity/Path/ui/Path';
import {useAppSelector} from "core/storage/hooks";
import {useDispatch} from "react-redux";
import {TRoute} from "core/entity/Route/model/model";
import H1 from "core/components/H/1/H1";
import FunctionTopLine from "core/widget/FunctionTopLine/ui/FunctionTopLine";
import {useLocation} from "react-router-dom";
import NotificationBell from "core/entity/Notification/ui/NotificationBell";

interface MainLayoutProps {
    children: ReactNode,
}

const MainLayout = ({ children }: MainLayoutProps) => {
    const dispatch = useDispatch();
    const path = useAppSelector(state => state.path);
    const location = useLocation();
    const isChartPage = location.pathname.startsWith('/chart')
    console.log(path)
    const [current, setCurrent] = React.useState<TRoute | undefined>(undefined);

    useEffect(() => {
        if (path.length > 0) {
            setCurrent(path[path.length - 1]);
        }
    }, [dispatch, path, setCurrent]);

    useEffect(() => {
        const title = current?.titlePath || current?.title
        document.title = title ? `${title} | ТаскМенеджер` : 'ТаскМенеджер'
    }, [current]);


    return (
        <div className={cl.layout}>
            <LeftBarMain className={cl.leftBar} />
            <div className={cl.content}>
                <Path />
                <div className={cl.topLine}>
                    {current !== undefined &&
                        <H1>{current.title}</H1>
                    }
                    <NotificationBell />
                </div>
                {!isChartPage && <FunctionTopLine />}
                {children}
            </div>
        </div>
    );
};

export default MainLayout;
