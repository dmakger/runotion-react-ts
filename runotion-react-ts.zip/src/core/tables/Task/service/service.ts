import {ITask} from "core/entity/Task/model/model";
import {ILineTable, ITable} from "core/widget/Table/model/model";
import {objToCellTable} from "core/widget/Table/service/service";
import {formattedData} from "core/service/date";

export const taskListToTableContent = (tasks: ITask[]): ITable["content"] => {
    return tasks.map(task => taskCellToTableContent(task));
};


export const taskCellToTableContent = (task: ITask) => {
    const nameCell = objToCellTable({obj: {title: task.name}, defaultText: 'Без названия'});
    const deadlineCell = objToCellTable({obj: {title: formattedData(task.deadline)}, defaultText: 'Без срока'});
    const categoryCell = objToCellTable({
        obj: {
            title: task.category?.name,
            color: task.category?.color,
        },
        defaultText: 'Без категории'
    });
    const stageCell = objToCellTable({
        obj: {
            title: task.section?.name,
            color: task.section?.color?.value,
        },
        defaultText: 'Без этапа'
    });
    const directorCell = objToCellTable({
        obj: {
            id: task.director.id,
            title: task.director.name,
            image: task.director.image,
            entity: 'user',
        }, defaultText: 'Без постановщика'
    });

    const responsibleCell = objToCellTable({
        obj: {
            id: task.responsible?.id,
            title: task.responsible?.name,
            image: task.responsible?.image,
            entity: 'user',
        },
        defaultText: 'Без ответственного'
    });

    const projectCell = objToCellTable({
        obj: {
            id: task.project.id,
            title: task.project.name,
            image: task.project.image,
            entity: 'project',
        }, defaultText: 'Без проекта'
    });

    return {
        id: task.id,
        line: [
            nameCell, deadlineCell, categoryCell, stageCell, directorCell, responsibleCell, projectCell
        ]
    } as ILineTable
}
