export enum EVariantKeyParam {
    LIMIT = 'limit',
    ORDERING = 'ordering',
}

export type IParams = Partial<Record<EVariantKeyParam | string, string>>

export interface IArgsRequest {
    body?: Record<string, any>,
    headers?: Record<string, string>
    params?: IParams
}


export interface IRequest {
    method: string,
    url: string,
    body?: string | FormData,
    headers?: Record<string, string>
    params?: IParams
}
