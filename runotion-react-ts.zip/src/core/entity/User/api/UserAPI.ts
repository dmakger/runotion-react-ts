import {getHeaders, getURL, request, URL_API} from "core/api/mainAPI";
import {IArgsRequest, IRequest} from "core/api/model/model";

const USER_API = URL_API + '/user'

// AUTH
export const login = async ({body}: IArgsRequest) => {
    const url = `${URL_API}/token/`
    const bodyJSON = JSON.stringify(body)

    return await request({
        method: 'POST',
        url: url,
        body: bodyJSON,
    } as IRequest)
}

export const refreshToken = async () => {
    const url = `${URL_API}/token/refresh/`

    const bodyJSON = JSON.stringify({'refresh': localStorage.getItem('refreshToken')})
    return await request({
        method: 'POST',
        url: url,
        body: bodyJSON,
    } as IRequest)
}


export const getUserData = async () => {
    const url = `${USER_API}/get/`
    const headers = getHeaders(true)
    return await request({method: 'GET', url, headers} as IRequest)
}

export const getUsersAPI = async (params?: IArgsRequest["params"]) => {
    const url = `${USER_API}/all/`
    const headers = getHeaders(true)
    return await request({method: 'GET', url: getURL(url, params), headers} as IRequest)
}

export const getUserByIdAPI = async (userId: number | string) => {
    const url = `${USER_API}/${userId}/`
    const headers = getHeaders(true)
    return await request({method: 'GET', url, headers} as IRequest)
}

export const createRegistrationRequestAPI = async (body: IArgsRequest["body"]) => {
    const url = `${USER_API}/registration-request/`
    return await request({
        method: 'POST',
        url,
        body: JSON.stringify(body),
    } as IRequest)
}

export const updateUserProfileAPI = async (userId: number | string, body: FormData) => {
    const url = `${USER_API}/${userId}/update/`
    return await request({
        method: 'PUT',
        url,
        headers: {
            Authorization: `Bearer ${localStorage.getItem('accessToken')}`,
        },
        body,
    } as IRequest)
}
